package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercico10Application {

	public static void main(String[] args) {
		SpringApplication.run(Ejercico10Application.class, args);
	}

}
