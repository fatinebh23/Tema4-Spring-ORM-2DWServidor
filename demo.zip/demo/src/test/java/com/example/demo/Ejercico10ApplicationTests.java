package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercico10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
