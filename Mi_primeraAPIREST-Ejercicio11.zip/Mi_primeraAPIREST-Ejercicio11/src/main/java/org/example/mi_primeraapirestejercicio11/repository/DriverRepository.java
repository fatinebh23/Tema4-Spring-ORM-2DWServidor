package org.example.mi_primeraapirestejercicio11.repository;

import org.example.mi_primeraapirestejercicio11.module.Driver;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DriverRepository extends JpaRepository<Driver, Long> {

}
