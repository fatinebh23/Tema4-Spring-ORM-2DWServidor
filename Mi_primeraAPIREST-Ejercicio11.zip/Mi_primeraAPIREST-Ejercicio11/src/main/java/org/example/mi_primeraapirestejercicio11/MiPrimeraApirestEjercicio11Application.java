package org.example.mi_primeraapirestejercicio11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiPrimeraApirestEjercicio11Application {

	public static void main(String[] args) {
		SpringApplication.run(MiPrimeraApirestEjercicio11Application.class, args);
	}

}
