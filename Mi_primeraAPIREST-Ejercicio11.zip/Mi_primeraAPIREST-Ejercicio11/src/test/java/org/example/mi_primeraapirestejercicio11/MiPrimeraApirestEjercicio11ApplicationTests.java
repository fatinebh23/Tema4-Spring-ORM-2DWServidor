package org.example.mi_primeraapirestejercicio11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiPrimeraApirestEjercicio11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
